import copy
import itertools
import torch
from torch.nn.modules import activation
from torch import nn, optim
from torch.nn import functional as F
from torch.autograd import Variable
from torch.optim.lr_scheduler import _LRScheduler, StepLR
from torch.utils.data import DataLoader
import torchvision.models as models


def initialize_weights(model):
    for m in model.modules():
        if isinstance(m, nn.Conv2d):
            m.weight.data = nn.init.xavier_normal_(m.weight.data)
            # m.weight.data = nn.init.kaiming_normal_(m.weight.data)
            if m.bias is not None:
                nn.init.normal_(m.bias)
            # m.weight.data.normal_(0, 0.02)
            # m.bias.data.zero_()
        elif isinstance(m, nn.ConvTranspose2d):
            m.weight.data = nn.init.xavier_normal_(m.weight.data)
            # m.weight.data = nn.init.kaiming_normal_(m.weight.data)
            if m.bias is not None:
                nn.init.normal_(m.bias)
            # m.weight.data.normal_(0, 0.02)
            # m.bias.data.zero_()
        elif isinstance(m, nn.Linear):
            m.weight.data = nn.init.kaiming_normal_(m.weight.data)
            if m.bias is not None:
                nn.init.normal_(m.bias)
            # m.weight.data.normal_(0, 0.02)
            # m.bias.data.zero_()


class Flatten(nn.Module):
    def __init__(self):
        super(Flatten, self).__init__()
    
    def forward(self, x):
        return torch.reshape(x, (x.size(0), -1))


def base_conv(in_ch, out_ch, ksize, stride=2):
    return nn.Sequential(nn.Conv2d(in_ch, out_ch, ksize, stride=stride, padding=(ksize-1)//2),
                                nn.BatchNorm2d(out_ch),
                                nn.ReLU())


def base_deconv(in_ch, out_ch):
    return nn.Sequential(nn.ConvTranspose2d(in_ch, out_ch, 2, stride=2),
                                nn.BatchNorm2d(out_ch),
                                nn.ReLU())


class DRLModel(nn.Module):
    def __init__(self, n_classes, ksize=3, img_w=256, img_h=256, latent_dim=256):
        super(SemiSelfClassifier, self).__init__()
        self.img_h, self.img_w = img_h, img_w
        self.latent_dim = latent_dim

        subnets = []
        classifiers = []
        disentangle_classifiers = []
        self.enc = models.resnet18(pretrained=False)
        self.enc = nn.Sequential(*list(self.enc.children())[:8])
        subnet_input_dim = 512

        for i in range(len(n_classes)):
            subnets.append(self.get_subnet(channel=subnet_input_dim, ksize=ksize, nconv=2))
            classifiers.append(nn.Linear(in_features=self.latent_dim, out_features=n_classes[i]))

        for i in [1, 0]:
            disentangle_classifiers.append(nn.Linear(in_features=self.latent_dim, out_features=n_classes[i]))

        self.subnets = nn.ModuleList(subnets)
        self.classifiers = nn.ModuleList(classifiers)
        self.disentangle_classifiers = nn.ModuleList(disentangle_classifiers)
        initialize_weights(self)

    def encode(self, input):
        h0 = self.enc(input)
        output_subnets = []
        for i in range(len(self.subnets)):
            output_subnets.append(self.subnets[i](h0))
        return output_subnets[0], output_subnets[1]

    def forward(self, input, latent=False):
        z1, z2 = self.encode(input)
        z1_no_grad = z1.clone().detach()
        z2_no_grad = z2.clone().detach()
        classifier_preds = []
        dis_classifier_preds = []
        classifier_preds.append(self.classifiers[0](z1))
        classifier_preds.append(self.classifiers[1](z2))
        dis_classifier_preds.append(self.disentangle_classifiers[0](z1))
        dis_classifier_preds.append(self.disentangle_classifiers[0](z1_no_grad))
        dis_classifier_preds.append(self.disentangle_classifiers[1](z2))
        dis_classifier_preds.append(self.disentangle_classifiers[1](z2_no_grad))
        return classifier_preds[0], classifier_preds[1], dis_classifier_preds[0], dis_classifier_preds[1], dis_classifier_preds[2], dis_classifier_preds[3]

    def predict_label(self, input):
        z1, z2 = self.encode(input)
        zs = [z1, z2]

        classifier_preds = []
        for i in range(len(self.classifiers)):
            classifier_preds.append(self.classifiers[i](zs[i]))
        
        return torch.argmax(classifier_preds[0], 1), torch.argmax(classifier_preds[1], 1)

    def predict_proba(self, input):
        z1, z2 = self.encode(input)
        zs = [z1, z2]

        classifier_preds = []
        for i in range(len(self.classifiers)):
            classifier_preds.append(self.classifiers[i](zs[i]))
        
        return classifier_preds[0], classifier_preds[1]
    
    def hidden_output(self, input):
        z1, z2 = self.encode(input)
        return z1, z2

    def get_subnet(self, channel, ksize, nconv):
        subnet_layers = []
        for i in range(nconv):
            subnet_layers.append(base_conv(channel, channel, ksize, stride=1))
        subnet_layers.append(nn.AvgPool2d(kernel_size=self.img_w//(2**5)))
        subnet_layers.append(Flatten())
        subnet_layers.append(nn.Linear(in_features=channel, out_features=self.latent_dim))
        subnet_layers.append(nn.ReLU())
        return nn.Sequential(*subnet_layers)