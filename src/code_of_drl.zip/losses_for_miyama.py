import itertools
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def negative_entropy_loss(input, small_value=1e-4):
    softmax_input = F.softmax(input, dim=1) + small_value
    log_input = torch.log(softmax_input)
    neg_entropy = torch.sum(-log_input, dim=1) / log_input.size()[1]
    return torch.mean(neg_entropy)